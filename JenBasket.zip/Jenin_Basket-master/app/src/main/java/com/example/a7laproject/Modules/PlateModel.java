package com.example.a7laproject.Modules;

public class PlateModel {
    public PlateModel(){
        //Empty Cosntructor
    }

    private int PlateImage;

    public PlateModel(int plateImage){
        this.PlateImage = PlateImage;
    }

    public int getPlateImage() {
        return PlateImage;
    }

    public void setPlateImage(int plateImage) {
        PlateImage = plateImage;
    }
}

