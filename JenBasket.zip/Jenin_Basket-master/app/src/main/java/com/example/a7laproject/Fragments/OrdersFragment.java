package com.example.a7laproject.Fragments;

import android.os.Bundle;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.a7laproject.R;
import com.google.android.material.internal.NavigationMenuView;
import com.google.android.material.navigation.NavigationView;


public class OrdersFragment extends Fragment implements View.OnClickListener {


    public OrdersFragment() {
        // Required empty public constructor
    }

   DrawerLayout drawerLayout;
    ImageView navigationBar;
    NavigationView navigationView;
    private View view;
    private RelativeLayout LoginSignUp,bookmarks,eightMMGold;
    private TextView your_order,favorite_order,address_book,online_ordering_help,send_feedback,Report_Safety_Emergency,rate_playstore;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_orders, container, false);


        onSetNavigationDrawerEvents();
        return view;
    }

    private void onSetNavigationDrawerEvents() {
        drawerLayout = (DrawerLayout) view.findViewById(R.id.drawerLayout);
        navigationView = (NavigationView) view.findViewById(R.id.navigationView);

        navigationBar = (ImageView) view.findViewById(R.id.navigationBar);

        LoginSignUp=(RelativeLayout)view.findViewById(R.id.relativeLayout2);
        bookmarks=(RelativeLayout)view.findViewById(R.id.relativeLayout3);
        eightMMGold=(RelativeLayout)view.findViewById(R.id.relativeLayout4);

        your_order=(TextView)view.findViewById(R.id.your_order);
        favorite_order=(TextView)view.findViewById(R.id.favorite_order);
        address_book=(TextView)view.findViewById(R.id.address_book);
        online_ordering_help=(TextView)view.findViewById(R.id.online_ordering_help);
        send_feedback=(TextView)view.findViewById(R.id.send_feedback);
        Report_Safety_Emergency=(TextView)view.findViewById(R.id.Report_Safety_Emergency);
        rate_playstore=(TextView)view.findViewById(R.id.rate_playstore);

        navigationBar.setOnClickListener(this);
        LoginSignUp.setOnClickListener(this);
        bookmarks.setOnClickListener(this);
        eightMMGold.setOnClickListener(this);
        your_order.setOnClickListener(this);
        favorite_order.setOnClickListener(this);
        address_book.setOnClickListener(this);
        online_ordering_help.setOnClickListener(this);
        send_feedback.setOnClickListener(this);
        Report_Safety_Emergency.setOnClickListener(this);
        rate_playstore.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.navigationBar:
                drawerLayout.openDrawer(navigationView, true);
                break;
            case R.id.relativeLayout2:;
                Toast.makeText(getContext(), "LoginSignUP", Toast.LENGTH_SHORT).show();
                break;
            case R.id.relativeLayout3:;
                Toast.makeText(getContext(), "bookmarks", Toast.LENGTH_SHORT).show();
                break;
            case R.id.relativeLayout4:;
                Toast.makeText(getContext(), " eightMMGold", Toast.LENGTH_SHORT).show();
                break;

            case R.id.your_order:
                Toast.makeText(getContext(), "your_order", Toast.LENGTH_SHORT).show();
                break;
            case R.id.online_ordering_help:;
                Toast.makeText(getContext(), "online_ordering_help", Toast.LENGTH_SHORT).show();
                break;
            case R.id.favorite_order:;
                Toast.makeText(getContext(), "favorite_order", Toast.LENGTH_SHORT).show();
                break;
            case R.id.address_book:;
                Toast.makeText(getContext(), "address_book", Toast.LENGTH_SHORT).show();
                break;
            case R.id.send_feedback:;
                Toast.makeText(getContext(), "send_feedback", Toast.LENGTH_SHORT).show();
                break;

            case R.id.Report_Safety_Emergency:;
                Toast.makeText(getContext(), "Report_Safety_Emergency", Toast.LENGTH_SHORT).show();
                break;
            case R.id.rate_playstore:;
                Toast.makeText(getContext(), "rate_playstore", Toast.LENGTH_SHORT).show();
                break;

            default:
                throw new IllegalStateException("Unexpected value: " + v.getId());
        }
    }
}